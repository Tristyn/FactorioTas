if not rq then rq = {} end

rq.q_per_page = 10 -- amount of items in the queue to be displayed on 1 page, 8 is ideal for 720p
rq.research_table_width = 10 --width of the table displaying all research, might want to increase this if the bottom of the research falls outside the screen.
rq.research_table_height = 9 --height of the table.

