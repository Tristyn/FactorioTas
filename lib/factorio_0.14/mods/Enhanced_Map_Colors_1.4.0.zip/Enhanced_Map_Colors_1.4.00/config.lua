--Enable 0.15.x Colors
Color_v15_Items = true

--[[ --IGNORE THIS CODE
Belt_Overlay_Functionality = false -- Use either true or false value. When set to true, any save game will take longer to load, may take too long
--]]

